package com.immersive.app.ui;

import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;

import com.immersive.app.R;

public class OnboardingActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            getWindow().setDecorFitsSystemWindows(false);
        }

        setContentView(R.layout.activity_onboarding);

        View root = findViewById(R.id.onboardingScroll);
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int pad = (int) (24 * getResources().getDisplayMetrics().density);
            v.setPadding(
                    pad + insets.getSystemWindowInsetLeft(),
                    pad + insets.getSystemWindowInsetTop(),
                    pad + insets.getSystemWindowInsetRight(),
                    pad + insets.getSystemWindowInsetBottom()
            );
            return insets;
        });

        Button btnAccept = findViewById(R.id.btnAcceptAndEnable);
        btnAccept.setOnClickListener(v -> {
            Intent intent = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        });

        Button btnDecline = findViewById(R.id.btnDecline);
        btnDecline.setOnClickListener(v -> finish());
    }
}
