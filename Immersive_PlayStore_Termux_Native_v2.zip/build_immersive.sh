#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail

echo "[*] Building Immersive (Termux Native Zero-Gradle Pipeline)..."

# 1. Locate android.jar
ANDROID_JAR="${ANDROID_JAR:-}"
if [ -z "$ANDROID_JAR" ]; then
    for candidate in         "$PREFIX/share/aapt2/android.jar"         "$PREFIX/share/java/android.jar"         "$HOME/android.jar"         "/data/data/com.termux/files/usr/share/aapt2/android.jar"; do
        if [ -f "$candidate" ]; then
            ANDROID_JAR="$candidate"
            break
        fi
    done
fi

if [ -z "$ANDROID_JAR" ] || [ ! -f "$ANDROID_JAR" ]; then
    echo "[!] android.jar not found. Set ANDROID_JAR=/path/to/android.jar and re-run."
    exit 1
fi
echo "[+] Using android.jar: $ANDROID_JAR"

# 2. Clean build directory
rm -rf build
mkdir -p build/gen build/obj build/dex

# 3. Compile & Link Resources via aapt2
echo "[*] Running aapt2 compile..."
aapt2 compile --dir app/src/main/res -o build/res.zip

echo "[*] Running aapt2 link..."
aapt2 link     -I "$ANDROID_JAR"     --manifest app/src/main/AndroidManifest.xml     --java build/gen     -o build/unsigned.apk     --auto-add-overlay     build/res.zip

# 4. Compile Java sources via javac
echo "[*] Compiling pure Java sources..."
find build/gen app/src/main/java -name "*.java" > build/sources.txt
javac     -source 11 -target 11     -classpath "$ANDROID_JAR"     -d build/obj     @build/sources.txt

# 5. Convert bytecode to DEX via d8
echo "[*] Dexing with d8..."
d8     --lib "$ANDROID_JAR"     --min-api 29     --output build/dex     $(find build/obj -name "*.class")

# 6. Inject classes.dex into APK
echo "[*] Packaging classes.dex..."
cp build/dex/classes.dex ./classes.dex
zip -uj build/unsigned.apk classes.dex
rm -f classes.dex

# 7. Zipalign (if available)
APK_TO_SIGN="build/unsigned.apk"
if command -v zipalign >/dev/null 2>&1; then
    echo "[*] Aligning APK..."
    zipalign -f -p 4 build/unsigned.apk build/aligned.apk
    APK_TO_SIGN="build/aligned.apk"
fi

# 8. Sign APK using release keystore
KEYSTORE="$HOME/release-key.keystore"
KEY_ALIAS="androidkey"
KEY_PASS="android123"

if [ ! -f "$KEYSTORE" ]; then
    echo "[*] Generating PKCS12 release keystore at $KEYSTORE..."
    keytool -genkeypair -v         -keystore "$KEYSTORE"         -storetype PKCS12         -alias "$KEY_ALIAS"         -keyalg RSA -keysize 2048 -validity 10000         -storepass "$KEY_PASS" -keypass "$KEY_PASS"         -dname "CN=Ben Psaila, OU=NewmanServices, O=NewmanVentures, L=Perth, ST=WA, C=AU"
fi

OUT_APK="build/Immersive-signed.apk"
echo "[*] Signing APK with apksigner..."
apksigner sign     --ks "$KEYSTORE"     --ks-key-alias "$KEY_ALIAS"     --ks-pass "pass:$KEY_PASS"     --key-pass "pass:$KEY_PASS"     --out "$OUT_APK"     "$APK_TO_SIGN"

apksigner verify "$OUT_APK"

if [ -d "/sdcard/Download" ] && [ -w "/sdcard/Download" ]; then
    cp "$OUT_APK" /sdcard/Download/Immersive-signed.apk
    echo "[+] SUCCESS: Copied signed APK to /sdcard/Download/Immersive-signed.apk"
else
    echo "[+] SUCCESS: Signed APK ready at $OUT_APK"
fi
