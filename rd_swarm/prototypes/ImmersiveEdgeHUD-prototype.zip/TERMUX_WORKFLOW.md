# Prototype Build Workflow (Termux + apksigner)

1. Extract this prototype `.zip` into a workspace folder (e.g. `~/proto_work`).
2. Compile resources via `aapt2 compile` + `aapt2 link` against `android.jar` (`--min-sdk-version 26 --target-sdk-version 35`).
3. Compile generated `R.java` and `app/src/main/java/**/*.java` with `javac -source 17 -target 17`.
4. Convert `.class` bytecode to `classes.dex` via `d8 --min-api 26`.
5. Package into an APK, align with `zipalign -f -p 4`, and sign with `apksigner sign` (v1+v2+v3).
