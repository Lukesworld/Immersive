package com.immersive.edgehud;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TextView tv = new TextView(this);
        tv.setText(getString(R.string.hud_status_ready));
        tv.setPadding(48, 96, 48, 96);
        setContentView(tv);
    }
}
