package com.immersive.gestureproto;

import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

public class GestureHapticActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setBackgroundColor(getColor(R.color.surface_obsidian));
        root.setPadding(48, 96, 48, 96);

        TextView title = new TextView(this);
        title.setText(getString(R.string.gesture_banner));
        title.setTextColor(getColor(R.color.binary_bit_one));
        title.setTextSize(18f);
        root.addView(title);

        TextView bits = new TextView(this);
        bits.setText("BITS [1010] -> BACK | HOME | RECENTS | HIDE");
        bits.setTextColor(0xFFE6FFF7);
        bits.setPadding(0, 24, 0, 0);
        root.addView(bits);

        setContentView(root);
        pulseHaptic();
    }

    private void pulseHaptic() {
        Object svc = getSystemService(VIBRATOR_SERVICE);
        if (svc instanceof Vibrator) {
            Vibrator vib = (Vibrator) svc;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vib.vibrate(VibrationEffect.createOneShot(25, VibrationEffect.DEFAULT_AMPLITUDE));
            } else {
                vib.vibrate(25);
            }
        }
    }
}
